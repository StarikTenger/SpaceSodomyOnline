Q - delete
E - wall
AWDS - corners
SPACE - spikes
1 - energy
2 - hp
3 - berserk
4 - immortal
5 - charge
6 - laser

SHIFT+CONTROL+N - new
CONTROL+S - save