#include "Mouse.h"



Mouse::Mouse()
{
}


Mouse::~Mouse()
{
}
