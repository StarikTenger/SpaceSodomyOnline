#include "Sound.h"

Sound::Sound(std::string _name, Vec2 _pos) {
	name = _name;
	pos = _pos;
}