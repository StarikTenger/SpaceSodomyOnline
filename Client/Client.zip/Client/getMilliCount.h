#pragma once
#include <cstdlib>
#include <string>
#include <sys/timeb.h>

int getMilliCount();
std::string getTime(int time);