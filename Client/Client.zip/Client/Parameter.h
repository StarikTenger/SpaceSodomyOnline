#pragma once
class Parameter {
public:
	int bullets = 0;
};

